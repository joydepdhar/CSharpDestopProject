﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_Management_System
{
    public partial class Add_New_Books : UserControl
    {
        public Add_New_Books()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You Want To Close The Application?", "Exit Maessage", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) ;
            {
                Application.Exit();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            DataAccess A = new DataAccess();
            string BID = BookID.Text;
            string BName = BookName.Text;
            string BAuthor = BookAuthor.Text;
            string BType = BookType.Text;
            string BPulication = BookPub.Text;
            string BQuantity = BookQuantity.Text;
            string Query = "insert into BookInfo(BookID,BookName,BookAuthor,BookType,bookPub, BQuantity) Values('" + BID + "','" + BName + "','" + BAuthor + "','" + BType + "','" + BPulication + "','"+BQuantity+"');";
            A.ExecuteDMLQuery(Query);
            MessageBox.Show("Data save");
        }
    }
}
